先设置镜像

```
yarn config set electron_mirror https://npm.taobao.org/mirrors/electron/
```
