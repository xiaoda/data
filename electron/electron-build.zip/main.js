// Modules to control application life and create native browser window
const {
  app,
  BrowserWindow,
  globalShortcut,
  protocol,
  Menu,
  dialog,
  session,
} = require('electron')
const path = require('path')
const { readFile } = require('fs')

// 防止 localStorage 不可访问
protocol.registerSchemesAsPrivileged([
  {
    scheme: 'app',
    privileges: {
      secure: true,
      standard: true,
    },
  },
])
function createWindow() {
  // Create the browser window.
  const mainWindow = new BrowserWindow({
    // width: 800,
    // height: 600,
    fullscreen: true,
    fullscreenable: true,
    webPreferences: {
      // preload: path.join(__dirname, 'preload.js'),
      webSecurity: false, // 禁用同源策略
      allowRunningInsecureContent: false, // 允许加载不安全资源
      autoplayPolicy: 'no-user-gesture-required', // 允许直接播放音视频
      nodeIntegration: true, // 设置开启nodejs环境
      enableRemoteModule: true, // enableRemoteModule保证renderer.js可以可以正常require('electron').remote，此选项默认关闭且网上很多资料没有提到
    },
  })
  mainWindow.webContents.session.setPermissionRequestHandler(
    (webContents, permission, callback) => {
      callback(true)
    }
  )
  // mainWindow.loadURL('app://./dist/index.html')
  // const pagePath = path.resolve(__dirname, './webgl/index.html')
  // const pagePath = path.resolve(__dirname, './dist/index.html')
  //
  // mainWindow.loadURL('http://172.24.121.33:8080/login')
  // mainWindow.loadURL('http://192.168.0.106:8081')
  // mainWindow.loadURL('http://192.168.59.3:8031')
  // mainWindow.loadURL('http://192.168.59.11:8080/')
  // mainWindow.loadURL('https://192.168.59.3/')
  // mainWindow.loadURL('http://localhost:8080/')
  mainWindow.loadFile('index.html')

  // mainWindow.loadURL('http://localhost:8080/')
  // mainWindow.loadURL(
  //   'https://192.168.59.10:3016/dmirobot/platform/accidentPlan/accidentPlan.html'
  // )

  // mainWindow.loadURL('https://192.168.108.92:3016/dmirobot/tecent/index.html')

  // mainWindow.loadFile(pagePath)

  mainWindow.setMenu(null)
  // 监听窗口关闭 销毁引用
  // mainWindow.on('closed', () => {
  //   mainWindow = null
  // })
  // Open the DevTools.
  mainWindow.webContents.openDevTools()
  return mainWindow
}

app.commandLine.appendSwitch('--ignore-certificate-errors')
app.commandLine.appendSwitch('--disable-http-cache')
// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
app.whenReady().then(() => {
  const mainWindow = createWindow()

  globalShortcut.register('ESC', () => {
    dialog
      .showMessageBox({
        type: 'info',
        title: '退出',
        noLink: true,
        message: '您确定要退出吗？',
        buttons: ['确定', '取消'],
      })
      .then((res) => {
        if (res.response === 0) {
          app.exit()
        }
      })
    // mainWindow.setFullScreen(false)
  })
  // globalShortcut.register('Enter', () => {
  //   mainWindow.setFullScreen(true)
  // })
  app.on('activate', function () {
    // On macOS it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })

  // app.on('ready', () => {})
})

// Quit when all windows are closed, except on macOS. There, it's common
// for applications and their menu bar to stay active until the user quits
// explicitly with Cmd + Q.
app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit()
})

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and require them here.
